#include "Hora.h"

class Funcion : public Hora
{
  private:
    string cveFuncion;
    int sala;
  public:
    Funcion():Hora(){ //default
      cveFuncion = "N/A";
      sala = 0;
    };
    Funcion(string cveFuncion, int sala):Hora(int h,int m){ //c parametros
      cveFuncion = cF;
      sala = s;
    };
    //metodos de modificacion
    void setCveFuncion(int cF){
      cveFuncion = cF;
    };
    void setSala(int s){
      sala = s;
    };
    //metodos de acceso
    string getCveFuncion(){
      return cveFuncion;
    };
    int getSala(){
      return sala;
    };
    void muestra()
}