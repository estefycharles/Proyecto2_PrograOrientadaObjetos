class Actor
{
  private:
    int id;
    string nombre;
  public:
    Actor(); //default
    Actor(int i, string nom);
    //metodos de modificacion
    void setId(int i){
      id = i;
    };
    void setNombre(string nom){
      nombre = nom;
    };
    //metodos de acceso
    int getId(){
      return id;
    };
    string getNombre(){
      return nombre
    };
}