//
//  main.cpp
////////////////////////////////////////////////////
// Nombre archivo: ProyectoP2
// Autor: Estefania Charles A01283472
// Fecha: 6 de Marzo 2020 Versión: 1
////////////////////////////////////////////////////

#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
using namespace std;
#include "Pelicula.h"
#include "Funcion.h"

int main() {
  //arreglos de mis clases
  Pelicula arrP[20], pelis;
  Funcion arrF[20], funciones;
  Actor arrA[20], actores;
  //inicializo valores
  string linea1, nom, linea2, gen, titulo, cF, tituloF, cFI, nomA;
  int id, pos=0, cont=0, numPeli, anio, dur, cantAct, agregar, pos2=0, cont2=0, nP, hh, mm, sala, posF, idA;
  char accion, end = 'a', resp ='n', fun;
  bool existe, nPV = false, encontro=false, tit=true, cveF=true, idAF=true;
  Hora horaP;
  //Abro el archivo de actores
  ifstream archivoEntrada1;
  archivoEntrada1.open("actores.txt");
  
  for (int i = 0; i<20; i++){
    archivoEntrada1>>id;
    getline(archivoEntrada1,nom);
    actores.setId(id);
    actores.setNombre(nom);
    arrA[i]=actores;
    cont++;
  }

  ifstream archivoEntrada2; //Abro el archivo de peliculas
  archivoEntrada2.open("peliculas.txt");

  while(archivoEntrada2>>numPeli>>anio>>dur>>gen>>cantAct){
    //agrega el valor leido al arreglo en su respec pos
    pelis.setNumPeli(numPeli);
    pelis.setAnio(anio);
    pelis.setDuracion(dur);
    pelis.setGenero(gen);
    //lee los actores a agregar
    for (int i = 0; i<cantAct; i++){
      archivoEntrada2>>agregar;
        for (int h = 0; h<20; h++){
          if (arrA[h].getId()==agregar)
            arrP[pos2].agregarActor(arrA[h]);
        }
    }
  
    getline(archivoEntrada2,titulo);
    pelis.setTitulo(titulo);
    arrP[pos2]=pelis;
    pos2++;
    cont2++;
    
  }//Termina de recorrer todas las posiciones del arch pelis

  //Pide los datos de las funciones
  do{
    cout<<"FUNCIONES."<<endl;
    cout<<"Clave de la funcion: ";
    cin>>cF;
    do{
      cout<<"Numero de pelicula: ";
      cin>>nP;
      for (int n = 0; n<20; n++){
        if(arrP[n].getNumPeli() == nP){
          nPV = true;
        }
      }
    }while(nPV == false);
    nPV = false;
    do{
      cout<<"Horario de la funcion 0->23 y 0->59 (hh mm): ";
      cin>>hh>>mm;
    }while((hh<0) || (hh>23) || (mm<0 || mm>59));
    do{
      cout<<"Sala de la funcion (#): ";
      cin>>sala;
    }while(sala<0);

    horaP.setHora(hh);
    horaP.setMin(mm);
    funciones.setCveFuncion(cF);
    funciones.setNumPF(nP);
    funciones.setHM(horaP);
    funciones.setSala(sala);
    arrF[posF]=funciones;
    posF++;

    do{
    cout<<"¿Desea agregar otra funcion? (s/n)";
    cin>>fun;
    fun = tolower(fun);
    }while(fun!='n' && fun!='s');

  }while(fun=='s');

  do{
    do{ //Menu de opciones
      cout<<"Teclea la opcion que desea llevar a cabo:"<<endl;;
      cout<<"A. Consulta de actores \nB. Consulta de peliculas \nC. Consulta de funciones disponibles \nD. Consulta de funciones por hora \nE. Consulta por clave de funcion \nF. Consulta de pelicula por actor \nG. Terminar "<<endl;
      cin >> accion;
      accion = toupper(accion);
    }while((accion!='A')&&(accion!='B')&&(accion!='C')&&(accion!='D')&&(accion!='E')&&(accion!='F')&&(accion!='G')); //Valido que la opcion sea correcta
    
    switch (accion) {
      case 'A': //consulta actores
            cout<<"ACTORES."<<endl;
            cout<<"Id"<<"     "<<"Nombre"<<endl;
            for (int i=0; i<cont; i++) {
                cout<<arrA[i].getId()<<"    "<<arrA[i].getNombre()<<endl;
            }
      break;
               
      case 'B': //consulta peliculas
            cout<<"PELICULAS."<<endl;
            cout << left 
            << setw(35) << "|Titulo" 
            << setw(10) << "|Anio" 
            << setw(10) << "|Duracion" 
            << setw(10) << "|Genero"
            << endl;
            pos2 = 0;
            
              for(int j=0; j<cont2; j++){
              cout << left 
              << setw(35) << arrP[j].getTitulo() 
              << setw(10) << arrP[j].getAnio() 
              << setw(10) << arrP[j].getDuracion()
              << setw(10) << arrP[j].getGenero()
              << endl;
            }
      break;
      
      case 'C': //consulta funciones
            cout<<"FUNCIONES."<<endl;
            cout << left 
            << setw(10) << "|Clave" 
            << setw(35) << "|Pelicula" 
            << setw(10) << "|Sala" 
            << setw(0) << "|Hora"
            << endl;
            for (int j=0; j<posF; j++){
              for (int h=0; h<cont2; h++){
                if(arrF[j].getNumPeli() == arrP[h].getNumPeli()){
                  tituloF = arrP[h].getTitulo();
                  h=cont2+1;
                }
              }
             cout << left 
             << setw(10) << arrF[j].getCveFuncion()
             << setw(35) << tituloF
             << setw(10) << arrF[j].getSala()
             << setw(0) << arrF[j].getHM().getHora()<<":"<<arrF[j].getHM().getMin()
             << endl;
            }
      break;

      case'D': //funciones por hora
           do{
           cout<<"Ingresa la hora 0->23 y 0->59 (hh mm) ";
           cin>>hh>>mm;
           }while((hh<0) || (hh>24) || (mm<0 || mm>59));
           cout << left 
              << setw(35) << "|Pelicula" 
              << setw(10) << "|Sala" 
              << endl;
           for(int j=0; j<posF; j++){
            if((arrF[j].getHM().getHora()==hh) && (arrF[j].getHM().getMin()==mm) && (tit=true)){
              encontro = true;
              
              tit=false;
              for (int h=0; h<cont2; h++){
                if(arrF[j].getNumPeli() == arrP[h].getNumPeli()){
                  tituloF = arrP[h].getTitulo();
                  h=cont2+1;
                }
              }
                cout << left 
                << setw(35) << tituloF
                << setw(10) << arrF[j].getSala()
                << endl;
                
            }
           }
           if (encontro==false)
            cout<<"No hay funciones en ese horario"<<endl;
      break;
      
      case 'E': //clave de funcion
          do{
            cout<<"Clave de la funcion: ";
            cin>>cFI;
            for(int j=0; j<posF; j++){
              if((arrF[j].getCveFuncion()==cFI)){
                cveF=false;
              }
            }
          }while(cveF==true);
          cout<<"FUNCIONES POR CLAVE."<<endl;
            cout << left  
            << setw(35) << "|Pelicula" 
            << setw(10) << "|Sala" 
            << setw(10) << "|Duracion"
            << setw(10) << "|Genero"
            << setw(0) << "|Hora"
            << endl;
            for (int j=0; j<posF; j++){
              if((arrF[j].getCveFuncion()==cFI)){
                for (int h=0; h<cont2; h++){
                  if(arrF[j].getNumPeli() == arrP[h].getNumPeli()){
                    tituloF = arrP[h].getTitulo();
                    h=cont2+1;
                  }
                }
              cout << left 
              << setw(35) << tituloF
              << setw(10) << arrF[j].getSala()
              << setw(10) << arrP[j].getDuracion()
              << setw(10) << arrP[j].getGenero()
              << setw(0) << arrF[j].getHM().getHora()<<":"<<arrF[j].getHM().getMin()
              << endl;
              }
            }
      break;

      case'F': //peliculas por actor
          do{
          cout<<"Id del actor: ";
          cin>>idA;
          for(int j=0; j<20; j++){
              if((arrA[j].getId()==idA)){
                idAF=false;
                j=21;
              }
          }
          }while(idAF==true);
          cout<<"FUNCIONES POR ACTOR."<<endl;
           cout << left  
           << setw(35) << "|Titulo" 
           << setw(10) << "|Anio" 
          << endl;
          for(int i=0; i<cont2; i++){
            for(int k=0; k<4; k++){
              if(arrP[i].getListaActores(k).getId()==arrA[k].getId()){
                cout << left  
                << setw(35) << arrP[i].getTitulo() 
                << setw(10) << arrP[i].getAnio() 
                << endl;
                k=11;
              }
            }
          }
      break;

      case 'G':
            cout<<"Fin del programa. Hasta luego!"<<endl;
            end='e';
            resp='n';
      break;

      default:
            cout<<"Opcion incorrecta. Intenta de nuevo"<<endl;
      break;
        }
        if (end!='e') {
            cout<<"¿Desea realizar otra consulta? (s/n) ";
            cin>>resp;
            resp = tolower(resp);
            if (resp!='s')
                cout<<"Hasta luego!"<<endl;
    }
    }while(resp=='s');

    archivoEntrada1.close();
    archivoEntrada2.close();
    return 0;
}
