#include "Hora.h"

class Funcion
{
  private:
    string cveFuncion;
    int sala;
    Hora hm;
    int numPeli;
  public:
    Funcion(){ //default
      cveFuncion = "N/A";
      sala = 0;
      Hora hoM(1,1);
      hm = hoM;

    };
    Funcion(string cF, int s, Hora hoM){ //c parametros
      cveFuncion = cF;
      sala = s;
      hm = hoM;
    };
    //metodos de modificacion
    void setCveFuncion(string cF){
      cveFuncion = cF;
    };
    void setSala(int s){
      sala = s;
    };
    void setHM(Hora hoM){
      hm = hoM;
    };
    void setNumPF(int nPF){
      numPeli = nPF;
    };
    //metodos de acceso
    string getCveFuncion(){
      return cveFuncion;
    };
    int getSala(){
      return sala;
    };
    Hora getHM(){
      return hm;
    };
    int getNumPeli(){
      return numPeli;
    };
    void muestra(){
      hm.muestra();
    };
};