class Hora
{
  private:
    int hh;
    int mm;
  public:
    Hora(){ //default
      hh = 0;
      mm = 0;
    }; 
    Hora(int h, int m){ //c parametros
      hh = h;
      mm = m;
    }; 
    //metodos de modificacion
    void setHora(int h){
      hh = h;
    };
    void setMin(int m){
      mm = m;
    };
    //metodos de acceso
    int getHora(){
      return hh;
    };
    int getMin(){
      return mm;
    };
    void muestra(){
      cout<<hh<<":"<<mm<<endl;
    };
};
