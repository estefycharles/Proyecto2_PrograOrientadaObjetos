#include "Actor.h"

class Pelicula 
{
private:
    int numPeli;
    string titulo;
    int anio;
    int duracion;
    string genero;
    int cantActores;
    Actor listaActores[10]; //se almacenan los actores
    
public:
    Pelicula(); //constructor default
    //metodos de modificacion
    void setNumPeli(int nP){
        numPeli = nP;
    }; 
    void setTitulo(string tit){
        titulo = tit;
    };
    void setAnio(int a){
        anio = a;
    };
    void setDuracion(int dur){
        duracion = dur;
    };
    void setGenero(string gen){
        genero = gen;
    };

    //metodos de acceso
    int getNumPeli(){
        return numPeli;
    }; 
    string getTitulo(){
        return titulo;
    };
    int getAnio(){
        return anio;
    };
    int getDuracion(){
        return duracion;
    };
    string getGenero(){
        return genero;
    };
    int getCantActores(){ //cant de actores que hay arr listaActores
        return cantActores;
    };
    Actor getListaActores(int subI){
        return listaActores[subI];
    };
    bool agregarActor(Actor act);
//Definicion de funciones
};

Pelicula::Pelicula(){ //constructor default
    numPeli = 0;
    titulo = "N/A";
    anio = 0;
    duracion = 0;
    genero = "N/A";
}

bool Pelicula::agregarActor(Actor act){ //recibe el actor a agregar
//    if (cantActores>10) //verifica que no haya mas de 10
 //     return false; 
  //  else{
        for (int i = 0; i<10; i++){
          if (listaActores[i].getId() < 1){
              listaActores[i] = act;
              cantActores++;
              return true;
             i = 11;
          }
          //return false;
   //     }
      }
    return 0;
}
